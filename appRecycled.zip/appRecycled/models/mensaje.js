/*
______ _____ _______   _______  _      ___________ 
| ___ \  ___/  __ \ \ / /  __ \| |    |  ___|  _  \
| |_/ / |__ | /  \/\ V /| /  \/| |    | |__ | | | |
|    /|  __|| |     \ / | |    | |    |  __|| | | |
| |\ \| |___| \__/\ | | | \__/\| |____| |___| |/ / 
\_| \_\____/ \____/ \_/  \____/\_____/\____/|___/  
*/
/* La plataforma líder de menudeo entre traperos */

/************ MENSAJE *************/
/***********************************/

/* const getAll = () => {
  return new Promise((resolve, reject) => {
    db.query("select * from mensajes", (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
};

const getById = pMensajeId => {
  return new Promise((resolve, reject) => {
    // cuando vaya un valor variable en la query, se pone ?
    // el segundo parámetro de la query es un array con tantos elementos como interrogaciones, para mostrar el valor variable
    db.query(
      "select * from mensajes where id = ?",
      [pClienteId],
      (err, rows) => {
        if (err) reject(err);
        if (rows.length === 0) {
          resolve(null);
        }
        resolve(rows[0]);
      }
    );
  });
};

const create = ({ nombre, mensaje }) => {
  return new Promise((resolve, reject) => {
    db.query(
      "insert into mensajes (nombre, mensaje ) values (?,?)",
      [nombre, mensaje],
      (err, result) => {
        if (err) reject(err);
        resolve(result);
      }
    );
  });
};

const deleteById = pMensajeId => {
  return new Promise((resolve, reject) => {
    db.query(
      "delete from mensajes where id = ?",
      [pMensajeId],
      (err, result) => {
        if (err) reject(err);
        resolve(result);
      }
    );
  });
};

module.exports = {
  getAll: getAll,
  getById: getById,
  create: create,
  deleteById: deleteById
};
 */
