/*
______ _____ _______   _______  _      ___________ 
| ___ \  ___/  __ \ \ / /  __ \| |    |  ___|  _  \
| |_/ / |__ | /  \/\ V /| /  \/| |    | |__ | | | |
|    /|  __|| |     \ / | |    | |    |  __|| | | |
| |\ \| |___| \__/\ | | | \__/\| |____| |___| |/ / 
\_| \_\____/ \____/ \_/  \____/\_____/\____/|___/  
*/
/* La plataforma líder de menudeo entre traperos */

/************ PRODUCTO *************/
/***********************************/

const getAll = () => {
  return new Promise((resolve, reject) => {
    db.query("select * from productos", (err, rows) => {
      if (err) {
        reject(err);
      } else {
        console.log(rows);
        resolve(rows);
      }
    });
  });
};
 
const getById = pClienteId => {
  return new Promise((resolve, reject) => {
    db.query(
      "select * from productos where id = ?",
      [pClienteId],
      (err, rows) => {
        if (err) reject(err);
        if (rows.length === 0) {
          resolve(null);
        }
        resolve(rows[0]);
      }
    );
  });
};

const create = ({ nombre, descripcion, precio, categoria, status, tipo }) => {
  return new Promise((resolve, reject) => {
    db.query(
      "insert into productos (nombre, descripcion, precio, categoria, status, tipo) values (?,?,?,?,?,?)",
      [nombre, descripcion, precio, categoria, status, tipo],
      (err, result) => {
        if (err) reject(err);
        resolve(result);
      }
    );
  });
};

const deleteById = pProductoId => {
  return new Promise((resolve, reject) => {
    db.query(
      "delete from productos where id = ?",
      [pProductoId],
      (err, result) => {
        if (err) reject(err);
        resolve(result);
      }
    );
  });
};

module.exports = {
  getAll: getAll,
 getById: getById,
 create: create,
 deleteById: deleteById
};
 
