const router = require("express").Router();

const apiUsuariosRouter = require("./api/usuarios");
const apiProductosRouter = require("./api/productos");
const apiMensajesRouter = require("./api/mensajes");

router.use("/usuarios", apiUsuariosRouter);
router.use("/productos", apiProductosRouter);

module.exports = router;
