 const router = require("express").Router();

const Producto = require("../../models/producto");

// Aquí irían los Middlewares

// GET http://localhost:3000/api/productos/
//Método GET para conseguir la Api con Jsons
router.get("/", async (req, res) => {
  console.log(req.payload);
  const rows = await Producto.getAll();
  console.log(rows);
  res.json(rows);
});

// GET http://localhost:3000/api/productos/:productoId
// Método GET para conseguir un solo producto con la Api
router.get("/:productoId", async (req, res) => {
  const cliente = await Producto.getById(req.params.productoId);
  res.json(cliente);
});

// POST http://localhost:3000/api/productos/
// Método POST para crear un productos nuevo
router.post("/", async (req, res) => {
  const result = await Producto.create(req.body);
  if (result["affectedRows"] === 1) {
    const producto = await Producto.getById(result["insertId"]);
    res.json(producto);
  } else {
    res.json({ error: "El producto no se ha insertado" });
  }
});

// DELETE http://localhost:3000/api/productos/
// Método DELETE para borrar un productos
router.delete("/:productoId", async (req, res) => {
  const result = await Producto.deleteById(req.params.productoId);
  if (result["affectedRows"] === 1) {
    res.json({ success: "El producto ha sido erradicado" });
  } else {
    res.json({ error: "El producto NO ha sido destruido" });
  }
});

module.exports = router;
 
